export const environment = {
    baseURL: `https://prod.dummyjson.com/recipes`
};
