export const environment = {
    baseURL: `https://dummyjson.com/recipes`
};
