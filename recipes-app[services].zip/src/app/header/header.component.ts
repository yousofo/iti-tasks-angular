import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CounterService } from '../services/counter.service';
import { AsyncPipe } from '@angular/common';
import { LanguageService } from '../services/language.service';

@Component({
  selector: 'app-header',
  imports: [RouterLink, RouterLinkActive , AsyncPipe],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  counter: any;
  counterService = inject(CounterService);
  languageService = inject(LanguageService);

  ngOnInit() {
    this.counter = this.counterService.getCounter();

    this.languageService.getLanguage().subscribe((response) => console.log(response))
  }
}
