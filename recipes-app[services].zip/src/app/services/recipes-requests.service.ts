import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class RecipesRequestsService {
  constructor(private http: HttpClient) {}

  getRecipesList(): Observable<any> {
    return this.http.get(`${environment.baseURL}/recipes`, {
      params: {
        limit: 10,
        sortBy: 'name',
        order: 'asc',
      },
      headers: {
        Authorization: 'ACCESS_TOKEN FROM API',
        'Accept-Language': 'ar',
      },
    });
  }

  getRecipeDetails(id: string): Observable<any> {
    return this.http.get(`${environment.baseURL}/recipes/${id}`);
  }

  addRecipe(data: any) {
    return this.http.post(`${environment.baseURL}/recipes`, data, {
      params: {},
      headers: {}
    });
  }
}

// npm install
// npm run build
// dist/index.html