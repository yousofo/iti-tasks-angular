import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LanguageService {
  private language = new BehaviorSubject<{
    currentLang: string;
    availableLangs: string[];
  }>({
    currentLang: 'en',
    availableLangs: ['en', 'ar', 'fr'],
  });
  constructor() {}

  getLanguage() {
    return this.language.asObservable();
  }

  updateLanguage(newLang: { currentLang: string; availableLangs: string[] }) {
    this.language.next(newLang);
  }
}
