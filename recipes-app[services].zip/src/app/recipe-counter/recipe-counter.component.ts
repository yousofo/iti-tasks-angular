import { Component } from '@angular/core';
import { CounterService } from '../services/counter.service';

@Component({
  selector: 'app-recipe-counter',
  imports: [],
  templateUrl: './recipe-counter.component.html',
  styleUrl: './recipe-counter.component.css',
})
export class RecipeCounterComponent {
  counter: number = 0;
  constructor(private counterService: CounterService) {}

  ngOnInit() {
    this.counterService
      .getCounter()
      .subscribe((response) => (this.counter = response));
  }

  decreaseCounter(){
    this.counterService.setCounter(this.counter - 1)
  }

  increaseCounter(){
    this.counterService.setCounter(this.counter + 1)
  }
}
