import { Component, inject } from '@angular/core';
import { Recipe } from '../types/recipe';
import { RecipeCardComponent } from '../recipe-card/recipe-card.component';
import { RecipesRequestsService } from '../services/recipes-requests.service';

@Component({
  selector: 'app-recipes-list',
  imports: [RecipeCardComponent],
  templateUrl: './recipes-list.component.html',
  styleUrl: './recipes-list.component.css',
})
export class RecipesListComponent {
  recipes!: Recipe[];
  recipesRequestsService = inject(RecipesRequestsService);

  ngOnInit() {
    this.recipesRequestsService
      .getRecipesList()
      .subscribe((response) => (this.recipes = response.recipes));
  }

  recivedFromChild(id: number) {
    console.log('FROM PARENT', id);
    // this.recipes = this.recipes.filter(recipe => recipe.id !== id)
  }
}
