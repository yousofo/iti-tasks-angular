import { Component, inject, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Recipe } from '../types/recipe';
import { RecipesRequestsService } from '../services/recipes-requests.service';

@Component({
  selector: 'app-recipe-details',
  imports: [],
  templateUrl: './recipe-details.component.html',
  styleUrl: './recipe-details.component.css',
})
export class RecipeDetailsComponent {
  // activatedRoute = inject(ActivatedRoute);
  @Input() id: string = '';
  recipe !: Recipe;
  recipesRequestsService = inject(RecipesRequestsService);
  ngOnInit() {
    // const params_id: string = this.activatedRoute.snapshot.params['id'];
    // console.log(params_id);
    this.recipesRequestsService
      .getRecipeDetails(this.id)
      .subscribe((response) => this.recipe = response);
  }
}
